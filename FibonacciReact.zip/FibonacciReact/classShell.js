"use strict";

var React = require('react');

var CLASSNAME = React.createClass({
	render: function(){
		return(

		);
	}
});

module.exports = CLASSNAME;