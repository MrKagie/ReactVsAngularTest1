"use strict";
var React = require('react');

var Main = React.createClass({
	  getInitialState: function() {
    return { 
      fibonacci:0
    };
  },
    fibonacci: function(val){ //Heavy recursive function to calculate a given fibonacci number
      val = parseInt(val);
      if(val < 1) {return 0;}
      else if(val === 1 || val === 2) {return 1;}
      else {return (this.fibonacci(val-1) + this.fibonacci(val-2));}
  },
    fibo: function(){ //Measure the time needed to calculate fibonacci numbers 0-24 twentyfive times
     var start = performance.now(); 
     var result = 0;
     for(var j = 0; j<100; j++){
      for(var i = 0; i<25; i++){
        result += this.fibonacci(i);
      }
    }
    this.setState({
      fibonacci: result //Set state result
    });
    var stop = performance.now(); 
    console.log("Call to calculate fibonacci (100j, 25i) took on average " + (stop - start)/100 + " milliseconds.");
    },
    componentDidMount: function() { //From the moment component mounts, start randomly calculating fibonacci numbers
      this.startFibo();
  },
  startFibo: function(){
    this.interval = setInterval(this.randomFibo, 5); //Calculate a fibonacci number every 5ms
  },
  stopFibo: function(){
     clearInterval(this.interval);
  },
    randomFibo: function(){
      var test = 5 +  Math.floor(Math.random()*20);
      var result = this.fibonacci(test);
      this.setState({
      fibonacci: result
    });
  },
  render: function(){
    return (
      <div>
         <button onClick={this.fibo}>Fibo 25</button>
         <button onClick={this.stopFibo}>Stop</button>
         <button onClick={this.startFibo}>Start</button>
        <div>The fibonacci number is: {this.state.fibonacci}</div>
      </div>
    )


  }
});

module.exports = Main; 