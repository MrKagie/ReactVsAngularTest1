"use strict";

var React = require('react');
var ReactDOM = require('react-dom');
var Main = require('./js/Main')


ReactDOM.render(<Main />, document.getElementById('app'));