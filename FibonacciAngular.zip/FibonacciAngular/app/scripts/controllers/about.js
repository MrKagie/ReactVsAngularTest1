'use strict';

/**
 * @ngdoc function
 * @name heavyCalcApp.controller:AboutCtrl
 * @description
 * # AboutCtrl
 * Controller of the heavyCalcApp
 */
angular.module('heavyCalcApp')
  .controller('AboutCtrl', function () {

  });
