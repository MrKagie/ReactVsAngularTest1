'use strict';

angular.module('heavyCalcApp')
  .controller('MainCtrl', function ($scope, $window, $interval) {
    var a = 0;
    var timer = $interval(function () {
      a = 5 + Math.floor(Math.random() * 20);
      $scope.value = fibonacci(a);
    }, 5);
    $scope.value = 0;

    /**
     * Fibonacci calculation
     */
    var fibonacci = function (val) {
      val = parseInt(val);

      if (val < 1) {
        return 0;
      }
      else if (val === 1 || val === 2) {
        return 1;
      }
      else {
        return (fibonacci(val - 1) + fibonacci(val - 2));
      }
    };

    /**
     * Start button function sets up timer
     */
    $scope.start = function () {
      //don't start a new timer if it is running
      if (angular.isDefined(timer)) {
        return;
      }

      //start new timer
      timer = $interval(function () {
        a = 5 + Math.floor(Math.random() * 20);
        $scope.value = fibonacci(a);
      }, 5);
    };

    /**
     * Stop button function stops timer
     */
    $scope.stop = function () {
      if (angular.isDefined(timer)) {
        $interval.cancel(timer);
        timer = undefined;
      }
    };

    /**
     * Fibo function stops the time if it is still running, and calculates the sum of the fibonacci function for
     * the numbers from 0 to 24
     */
    $scope.fibo = function () {
      if (angular.isDefined(timer)) {
        $interval.cancel(timer);
        timer = undefined;
      }

      //actual calculation
      var t0 = performance.now();

      var result = 0;
      for (var j = 0; j < 100; j++) {
        for (var i = 0; i < 25; i++) {
          result += fibonacci(i);
        }
      }
      $scope.value = result;
      var t1 = performance.now();
      console.log("Call to calculate fibonacci (100j, 25i) took on average " + ((t1 - t0)/100) + " milliseconds.");

    };
  });
